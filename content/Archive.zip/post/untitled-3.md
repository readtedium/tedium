+++
author = "Ernie Smith"
date = 2017-11-17T08:28:38Z
description = ""
draft = true
slug = "untitled-3"
variant = "article"
title = "(Untitled)"

+++

{{% adbox bgcolor="#bcdddb" color="#333333" accent="#01645f" %}}

[![Bombas](https://tedium.imgix.net/2017/11/bombas_xmas.jpg)](http://bit.ly/2feJvyI)

**[​Like little sweaters for your feet](http://bit.ly/2feJvyI):** When it comes time to go dashing through the snow, you’ll want the right pair of socks on—Bombas' Merino wool socks. **[Use the code TEDIUM on your first order](http://bit.ly/2feJvyI)** to get 20% off!

{{% small %}}**[Bombas](http://bit.ly/2feJvyI)** is giving today's Tedium a push. [Learn how you can do the same](http://tedium.co/advertising/).{{% /small %}}

{{% /adbox %}}