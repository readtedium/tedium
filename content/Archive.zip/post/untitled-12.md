+++
author = "Ernie Smith"
date = 2018-07-29T22:37:22Z
description = ""
draft = true
slug = "untitled-12"
variant = "article"
title = "(Untitled)"

+++

![](https://tedium.imgix.net/2018/07/silkscreen.svg)

![](https://tedium.imgix.net/2018/08/IMG_3755.jpg)

![](https://tedium.imgix.net/2018/08/IMG_3754.jpg)