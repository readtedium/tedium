+++
author = "Ernie Smith"
date = 2018-03-06T03:39:43Z
description = ""
draft = true
slug = "untitled-5"
variant = "article"
title = "(Untitled)"

+++

<style type="text/css">.md-adbox a, .md-adbox b, .md-adbox strong{color: #ef2029 !important;}.md-adbox {background-color: #000000 !important;}.md-adbox p {color: #ffffff !important;}</style>

<div class="md-adbox" style="background-size: cover; background-image: url(https://tedium.imgix.net/2018/03/Tedium-Restaurant-Backdrop-800x480-2.jpg) !important; background-size: cover; background-position: center;">

<p style="margin-bottom: 10px;"><a href="https://www.thefrontporchpeople.com/design-everywhere/"><img src="https://tedium.imgix.net/2018/03/Tedium-Ad1-DesignEverywhere-300x300.gif" alt="Design Everywhere" title=""></a></p>

<p><strong>Ever wonder how furniture was created for fast food restaurants?</strong> Explore the great minds behind these design experiences and much more on <a href="https://www.thefrontporchpeople.com/design-everywhere/">Design Everywhere</a>, a new podcast created by designers, for designers. Presented by The Front Porch People, where great conversations happen. </p>

<p class="md-small">Today’s Tedium is sponsored by <a href="https://www.thefrontporchpeople.com/design-everywhere/">Design Everywhere</a>. (<a href="https://tedium.co/advertising/">See yourself in this space</a>?)</p>

</div>

&nbsp;


