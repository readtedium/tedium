+++
author = "Ernie Smith"
date = 2018-05-10T19:24:32Z
description = ""
draft = true
slug = "untitled-10"
variant = "article"
title = "(Untitled)"

+++

{{% adbox bgcolor="#37bb9a" color="#ffffff" accent="#ffffff" %}}

{{% leftbox %}}

[![Jamf Now](https://tedium.imgix.net/2018/05/macrumors-300x300.png)](https://www.paved.com/redirect/ex7qvnaghyn83xggcs8r7ycvypl)

{{% /leftbox %}}{{% rightbox %}}

<p><strong><a href="https://www.paved.com/redirect/ex7qvnaghyn83xggcs8r7ycvypl" target="_blank">Make managing your Apple devices easy</a>!</strong> Jamf Now is a device management solution for the iPad, iPhone and Mac devices at work. We make management tasks simple and affordable, so you can support your users; no IT required. <a href="https://www.paved.com/redirect/h3khy8p4fgjcpn4ol24kwxqmez" target="_blank">Create your free account</a>!</p>

{{% small %}}Today's Tedium [is sponsored by Jamf Now](https://www.paved.com/redirect/ex7qvnaghyn83xggcs8r7ycvypl). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

<img src="https://www.paved.com/open/370.gif?opens=1" width="1" height="1" style="    width: 1px; padding: 0; margin: 0;">

{{% /rightbox %}}{{% /adbox %}}