+++
author = "Ernie Smith"
date = 2018-05-16T01:07:22Z
description = ""
draft = true
slug = "untitled-11"
variant = "article"
title = "(Untitled)"

+++

{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

{{% leftbox %}}

[![Blind](https://tedium.imgix.net/2018/05/blindlogo.png)](https://www.paved.com/redirect/ex7qvnaghyn83xggcs8r7ycvypl)

{{% /leftbox %}}{{% rightbox %}}

**BLIND - The Anonymous Employee Social App:** Think your company needs to be more transparent? That’s why we created Blind, an anonymous community app for the workplace. By bringing anonymity to the workplace, Blind allows employees to have unfiltered conversations with coworkers. Download the app and join your coworkers now! Click [**HERE**](https://go.onelink.me/app/22dc730) to download for iOS or [**HERE**](https://go.onelink.me/app/3bddc461) to download for Android.

{{% small %}}Today's Tedium [is sponsored by Blind]). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /rightbox %}}{{% /adbox %}}

{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

[![Blind](https://tedium.imgix.net/2018/05/blindlogo.png)](https://www.paved.com/redirect/ex7qvnaghyn83xggcs8r7ycvypl)

<span style="font-size: 75%; line-height: 80%;">**BLIND—The Anonymous Employee Social App:** Think your company needs to be more transparent? That’s why we created Blind, an anonymous community app for the workplace. By bringing anonymity to the workplace, Blind allows employees to have unfiltered conversations with coworkers. Download the app and join your coworkers now! Click [**HERE**](http://) to download for iOS or [**HERE**](https://go.onelink.me/app/3bddc461) to download for Android.</span>

{{% small %}}Today's Tedium [is sponsored by Blind](https://www.paved.com/redirect/ex7qvnaghyn83xggcs8r7ycvypl). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /adbox %}}