+++
author = "Ernie Smith"
date = 2018-01-15T21:28:36Z
description = ""
draft = true
slug = "untitled-8"
variant = "article"
title = "(Untitled)"

+++

![](https://tedium.imgix.net/2018/01/triangles_topleft-1.png)

![](https://tedium.imgix.net/2018/02/thewell-bw.png)