+++
author = "Ernie Smith"
date = 2017-10-24T19:14:28Z
description = ""
draft = true
slug = "bombas-ad-sample"
variant = "article"
title = "Bombas Ad Sample #1"

+++

{{% adbox bgcolor="#aad3ec" color="#333333" accent="#2859ca" %}}

[![Bombas](https://tedium.imgix.net/2017/10/bombas.jpg)](http://bit.ly/2feJvyI)

**[Look Good, Feel Good, Do Good](http://bit.ly/2feJvyI):** Before launching Bombas, we learned that socks were the number one most requested clothing item at homeless shelters. So, we started a company with the goal of solving that problem. **[Use the code TEDIUM on your first order](http://bit.ly/2feJvyI)** to get 20% off!

{{% small %}}**[Bombas](http://bit.ly/2feJvyI)** is giving today's Tedium a push. [Learn how you can do the same](http://tedium.co/advertising/).{{% /small %}}

{{% /adbox %}}