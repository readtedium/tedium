+++
author = "Ernie Smith"
date = 2018-03-20T23:18:02Z
description = ""
draft = true
slug = "untitled"
variant = "article"
title = "(Untitled)"

+++

<style type="text/css">.md-adbox a, .md-adbox b, .md-adbox strong{color: #ef2029 !important;}.md-adbox {background-color: #000000 !important;}.md-adbox p {color: #ffffff !important;}</style>

<div class="md-adbox" style="background-size: cover; background-image: url(https://tedium.imgix.net/2018/03/FP-TediumAd3-FutureCity-800x480.jpg) !important; background-size: cover; background-position: center;">

<p style="margin-bottom: 10px;"><a href="https://www.thefrontporchpeople.com/design-everywhere/design-is-everywhere"><img src="https://tedium.imgix.net/2018/03/Tedium-Ad1-DesignEverywhere-300x300.gif" alt="Design Everywhere" title=""></a></p>

<p><strong>What is the one thing designers are tasked with? To imagine the future.</strong> Listen to <em><a href="https://www.thefrontporchpeople.com/design-everywhere/design-is-everywhere">Design Everywhere</a></em>, the new podcast that invites you to ask ‘what if’ and challenges you to understand ‘the why’ that drives your design. Presented by The Front Porch People, where great conversations happen. </p>

<p class="md-small">Today’s Tedium is sponsored by <a href="https://www.thefrontporchpeople.com/design-everywhere/design-is-everywhere">Design Everywhere</a>. (<a href="https://tedium.co/advertising/">See yourself in this space</a>?)</p>

</div>

&nbsp;

![](https://tedium.imgix.net/2018/04/tedium_intro.gif)