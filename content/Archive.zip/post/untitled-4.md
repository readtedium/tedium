+++
author = "Ernie Smith"
date = 2017-11-24T07:07:01Z
description = ""
draft = true
slug = "untitled-4"
variant = "article"
title = "(Untitled)"

+++

{{% adbox bgcolor="#d2e4ff" color="#333333" accent="#1a75fa" %}}

{{% leftbox %}}

[![Blinkist](https://tedium.imgix.net/2017/11/blinkist2.jpg)](http://bit.ly/2zZ8jFT)

{{% /leftbox %}}{{% rightbox %}}

**[Read or listen to the key ideas](http://bit.ly/2zZ8jFT)** from "7 Habits of Highly Effective People" and 2000+ nonfiction books in 15 minutes with the Blinkist app! Download the app for free now. Available on iOS and Android.

{{% small %}}Today's Tedium is **[sponsored by Blinkist](http://bit.ly/2zZ8jFT)**. [Learn how to advertise here](http://tedium.co/advertising/), too.{{% /small %}}

{{% /rightbox %}}{{% /adbox %}}


{{% adbox bgcolor="#d2ddec" color="#333333" accent="#1a75fa" %}}

[![Blinkist](https://tedium.imgix.net/2017/11/blinkist2.jpg)](http://bit.ly/2zZ8jFT)

**[Read or listen to the key ideas](http://bit.ly/2zZ8jFT)** from "7 Habits of Highly Effective People" and 2000+ nonfiction books in 15 minutes with the Blinkist app! Download the app for free now. Available on iOS and Android.

{{% small %}}Today's Tedium is **[sponsored by Blinkist](http://bit.ly/2zZ8jFT)**. [Learn how to advertise here](http://tedium.co/advertising/), too.{{% /small %}}

{{% /adbox %}}