+++
author = "Ernie Smith"
date = 2017-11-03T05:58:34Z
description = ""
draft = true
slug = "untitled-2"
variant = "article"
title = "(Untitled)"

+++

{{% adbox bgcolor="#F1F6F4" color="#333333" accent="#30c673" %}}

{{% leftbox %}}

[![Blinkist](https://tedium.imgix.net/2017/11/blinkist.jpg)](http://bit.ly/2zapsw3)

{{% /leftbox %}}{{% rightbox %}}

**[Meet The App That Revolutionized Book Reading For 3 Million People](http://bit.ly/2zapsw3).** The Blinkist app offers key takeaways from bestselling nonfiction books in bitesize text and audio. **[Find out here why and how](http://bit.ly/2zapsw3)** over 3 million people are overhauling the way that they read.

{{% small %}}Today's Tedium is **[sponsored by Blinkist](http://bit.ly/2zapsw3)**. [Learn how to advertise here](http://tedium.co/advertising/), too.{{% /small %}}

{{% /rightbox %}}{{% /adbox %}}


{{% adbox bgcolor="#F1F6F4" color="#333333" accent="#30c673" %}}

[![Blinkist](https://tedium.imgix.net/2017/11/blinkist.jpg)](http://bit.ly/2zapsw3)

**[Meet The App That Revolutionized Book Reading For 3 Million People](http://bit.ly/2zapsw3).** The Blinkist app offers key takeaways from bestselling nonfiction books in bitesize text and audio. **[Find out here why and how](http://bit.ly/2zapsw3)** over 3 million people are overhauling the way that they read.

{{% small %}}Today's Tedium is **[sponsored by Blinkist](http://bit.ly/2zapsw3)**. [Learn how to advertise here](http://tedium.co/advertising/), too.{{% /small %}}

{{% /adbox %}}