+++
author = "Ernie Smith"
date = 2018-01-03T03:42:08Z
description = ""
draft = true
slug = "untitled-7"
title = "(Untitled)"

+++

{{% adbox bgcolor="#d2ddec" color="#333333" accent="#1a75fa" %}}

[![Tedium on Patreon](https://tedium.imgix.net/2018/01/habits.jpg)](http://bit.ly/2juBZFf)

**Read or listen to the key ideas** from "7 Habits of Highly Effective People" and 2000+ nonfiction books in 15 minutes with the Blinkist app! [Download the app for free now](http://bit.ly/2juBZFf). Available on [iOS](http://bit.ly/2jvVSaF) and [Android](http://bit.ly/2zZ8jFT).

{{% small %}}Today's issue is brought to you by [Blinkist](http://bit.ly/2juBZFf). ([See yourself here](http://tedium.co/advertising/)?){{% /small %}}

{{% /adbox %}}


{{% adbox bgcolor="#d2ddec" color="#333333" accent="#1a75fa" %}}

{{% leftbox %}}

[![Tedium on Patreon](https://tedium.imgix.net/2018/01/habits.jpg)](http://bit.ly/2juBZFf)

{{% /leftbox %}}[rightbox]

**Read or listen to the key ideas** from "7 Habits of Highly Effective People" and 2000+ nonfiction books in 15 minutes with the Blinkist app! [Download the app for free now](http://bit.ly/2juBZFf). Available on [iOS](http://bit.ly/2jvVSaF) and [Android](http://bit.ly/2zZ8jFT).

{{% small %}}Today's issue is brought to you by Blinkist. ([See yourself here](http://tedium.co/advertising/)?){{% /small %}}

[/rightbox]{{% /adbox %}}