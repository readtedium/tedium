+++
author = "Ernie Smith"
date = 2018-03-16T01:16:51Z
description = ""
draft = true
slug = "untitled-9"
variant = "article"
title = "(Untitled)"

+++

<style type="text/css">.md-adbox a, .md-adbox b, .md-adbox strong{color: #ef2029 !important;}.md-adbox {background-color: #000000 !important;}.md-adbox p {color: #ffffff !important;}</style>

<div class="md-adbox" style="background-size: cover; background-image: url(https://tedium.imgix.net/2018/03/Tedium-Ad2-Background-800x480.jpg) !important; background-size: cover; background-position: center;">

<p style="margin-bottom: 10px;"><a href="https://www.thefrontporchpeople.com/design-everywhere/design-is-everywhere"><img src="https://tedium.imgix.net/2018/03/Tedium-Ad1-DesignEverywhere-300x300.gif" alt="Design Everywhere" title=""></a></p>

<p><strong>The most profound technologies are the ones that disappear.</strong> Listen to <em><a href="https://www.thefrontporchpeople.com/design-everywhere/design-is-everywhere">Design Everywhere</a></em> to explore a multitude of perspectives in one of the most exciting and disrupting eras in the history of design. Presented by The Front Porch People  where great conversations happen.</p>

<p class="md-small">Today’s Tedium is sponsored by <a href="https://www.thefrontporchpeople.com/design-everywhere/design-is-everywhere">Design Everywhere</a>. (<a href="https://tedium.co/advertising/">See yourself in this space</a>?)</p>

</div>

&nbsp;


