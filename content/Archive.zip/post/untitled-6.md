+++
author = "Ernie Smith"
date = 2017-12-06T02:02:55Z
description = ""
draft = true
slug = "untitled-6"
variant = "article"
title = "Topic Ads"

+++

{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

[![Topic.com](https://tedium.imgix.net/2017/12/1228_duetstopic.jpg)](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image)

<span style="font-size: 1.2em">**SantaCon, pop duets, and demon hunting.** Curious yet? [Subscribe to the newsletter](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image) the NYTimes calls ‘stunning’.</span>

{{% small %}}Today's issue is sponsored by [Topic](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /adbox %}}


{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

[![Topic.com](https://tedium.imgix.net/2017/12/1228_witchestopic.jpg)](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image)

<span style="font-size: 1.2em">**Activist witches, El Chapo and the magic of animal menopause.** They’re all found on Topic. [Explore Topic.com](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image): Visual stories for curious people.</em>

{{% small %}}Today's issue is sponsored by [Topic](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /adbox %}}


{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

{{% leftbox %}}

[![Topic.com](https://tedium.imgix.net/2017/12/topic_padded.png)](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image)

{{% /leftbox %}}{{% rightbox %}}

**Love motels, foul play, and 88 skies.** All in your inbox each week. [Subscribe to the newsletter](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image) the NYTimes calls ‘stunning’ and receive the latest from Topic.

{{% small %}}Today's issue is sponsored by [Topic](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /rightbox %}}{{% /adbox %}}




----


{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

[![Topic.com](https://tedium.imgix.net/2017/12/topic_padded.png)](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image)

<span style="font-size: 1.2em">**Cowboy cliches, El Chapo and the magic of animal menopause.** Curious yet? [Subscribe here](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image) to receive more visual stories for curious people. </span>

{{% small %}}Today's issue is sponsored by [Topic](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /adbox %}}


{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

[![Topic.com](https://tedium.imgix.net/2017/12/topic_padded.png)](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image )

<span style="font-size: 1.2em">**Bonfires, relationship failures and puppies. Curious yet?** [Explore Topic’s December issue](https://www.topic.com/?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image) - Gifted.</em>

{{% small %}}Today's issue is sponsored by [Topic](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /adbox %}}


{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

{{% leftbox %}}

[![Topic.com](https://tedium.imgix.net/2017/12/topic_padded.png)](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image)

{{% /leftbox %}}{{% rightbox %}}

**Love motels, foul play, and 88 skies.** All in your inbox each week. [Subscribe to the newsletter](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image) the NYTimes calls ‘stunning’ and receive the latest from Topic.

{{% small %}}Today's issue is sponsored by [Topic](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /rightbox %}}{{% /adbox %}}



{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

[![Topic.com](https://tedium.imgix.net/2017/12/topic_padded.png)](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image)

<span style="font-size: 1.2em">**Love motels, foul play, and 88 skies.** All in your inbox each week. [Subscribe to the newsletter](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image) the NYTimes calls ‘stunning.’</span>

{{% small %}}Today's issue is sponsored by [Topic](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /adbox %}}


----


{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

[![Topic.com](https://tedium.imgix.net/2017/12/topic_ladiesroom2.jpg)](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image)

**Loot, the ladies’ room, and a pair of matching handguns.** Curious? [Subscribe to the newsletter](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image) the NYTimes calls ‘stunning’ and receive the latest from Topic.

{{% small %}}Today's issue is sponsored by [Topic](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /adbox %}}

----

{{% adbox bgcolor="#000000" color="#ffffff" accent="#ffffff" %}}

[![Topic.com](https://tedium.imgix.net/2017/12/topic_padded.png)](https://www.topic.com/signup?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image)

<span style="font-size: 1.2em">**Addiction, Hollywood retirement homes and Bar Mitzvah party starters.** Curious? [Explore Topic’s December issue](https://www.topic.com/gifted?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image)—Gifted.</span>

{{% small %}}Today's issue is sponsored by [Topic](https://www.topic.com?utm_source=tedium&utm_medium=email&utm_campaign=paidpromo&utm_term=newsletterlink&utm_content=image). ([See yourself here](https://tedium.co/advertising/)?){{% /small %}}

{{% /adbox %}}








